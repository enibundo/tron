package types;

public abstract class AbstractType {
	
	public byte[] constructArr(byte header, byte[] rest){
		byte[] newArr = new byte[rest.length + 1];
		newArr[0]=header;
		for (int i=0; i<rest.length; i++) {
			newArr[i+1]=rest[i];
		}
		return newArr;
	}
}
