package types;

import types.interfaces.IMyType;

public class TUInt8 
extends AbstractType 
implements IMyType{
	public short getValue() {
		return value;
	}

	public void setValue(short value) {
		this.value = value;
	}

	private short value;
	
	public TUInt8(byte[] tab){
		this.value= (short) (0x000000FF & ((int)tab[0]));
	}
	
	public TUInt8(short value) {
		if ( (value&(1<<9-1)) < 0 
			|| value > 255){
			throw new RuntimeException("bad value TUInt8");
		}
		this.value = value;
	}

	public TUInt8(int value) {
		if (value < 0
			|| value > 255) {
			throw new RuntimeException("bad value TUInt8");
		}
		this.value = (short)value;
	}
	
	@Override
	public byte[] getBytes() {
		return new byte[]{(byte)value};
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x11, getBytes());
	}
	
	public String toString() {
		return "uint8 "+value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TUInt8) {
			return this.getValue()==((TUInt8)i).getValue();
		}
		return false;
	}
	
	
}
