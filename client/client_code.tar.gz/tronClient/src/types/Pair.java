package types;

public class Pair {
	private String s;
	private Object o;
	
	public Pair(String s, Object o){
		this.s = s;
		this.o = o;
	}
	
	public String getFirst() { 
		return s;
	}
	
	public Object getSecond() { 
		return o;
	}

}
