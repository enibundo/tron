package types;

import java.util.HashMap;
import java.util.Map;

import tools.ArrayTools;
import types.interfaces.IMyType;
import types.TFrame;

public class TFrame implements IMyType {

	private TUInt8 id;
	private int id_int;
	
	private TUInt8 n;
	private int n_int;
	
	private IMyType[] data;
	
	private Map<String, Class<?>> names;
	
	private TFrame() {
		names = new HashMap<String, Class<?>>();
		names.put("int8", TInt8.class);
		names.put("int16", TInt16.class);
		names.put("int32", TInt32.class);
		names.put("uint8", TUInt8.class);
		names.put("uint16", TUInt16.class);
		names.put("uint32", TUInt32.class);
		names.put("string", TString.class);
		names.put("double", TDouble.class);
	}
	
	public TFrame(int id, int n) {
		// construct names[]
		this();
		
		this.id = new TUInt8(id);
		id_int = id;
		
		this.n = new TUInt8(n);
		n_int = n;
		
		data=null;
		
	}
	
	public TFrame(int id, IMyType first) {
		this(id, 1);
		data = new IMyType[1];
		data[0] = first;
	}
	
	public TFrame(int id, IMyType[] data) {
		this(id, data.length);
		this.data = data;
	}
	
	public TFrame(int id) {
		this(id, 0);
	}
	@Override
	public byte[] getBytes() {
		int len=0;
		byte[][] tmp=new byte[n_int][];
		for (int i = 0; i < n_int; i++){
			tmp[i] = data[i].getPBytes();
			len += tmp[i].length;
		}
		byte[] res = new byte[len+3];
	
		res[0]=(byte)0xFF;
		res[1]=(byte)id_int;
		res[2]=(byte)n_int;
		
		int cnt=3;
		
		for (int i =0; i<n_int; i++) {
			for (int j=0; j<tmp[i].length; j++) {
				res[cnt] = tmp[i][j];
				cnt++;
			}
		}
		return res;
	}

	@Override
	public byte[] getPBytes() {
		return getBytes();
	}

	public boolean isEmpty(){ 
		return ( (data==null) || 
				 (data.length==0) );
	}
	
	public String toString() {
		String resultat = "{ ";
		resultat += "0x"+Integer.toHexString(id_int);
		for (int i=0; i<data.length; i++) {
			resultat += ", "+data[i].toString();
		}
		resultat += " }";
		return resultat;
	}
	
	
	
	public TUInt8 getId() {
		return id;
	}

	public void setId(TUInt8 id) {
		this.id = id;
	}

	public int getId_int() {
		return id_int;
	}

	public void setId_int(int idInt) {
		id_int = idInt;
	}

	public TUInt8 getN() {
		return n;
	}

	public void setN(TUInt8 n) {
		this.n = n;
	}

	public int getN_int() {
		return n_int;
	}

	public void setN_int(int nInt) {
		n_int = nInt;
	}

	public IMyType[] getData() {
		return data;
	}

	public void setData(IMyType[] data) {
		this.data = data;
	}

	public IMyType getData(int i){
		return data[i];
	}
	
	public boolean equals(IMyType f1) {
		if (f1 instanceof TFrame)
			return (this.getN().equals(((TFrame)f1).getN()) &&
					this.getId().equals(((TFrame)f1).getId()) &&
					ArrayTools.equal(this.getBytes(), f1.getBytes()));
		return false;
			
	}
	
	public boolean hasData(int position, IMyType i){
		return data[position].equals(i);
	}
	
	/*
	 * string -> TSTring
	 * int8 -> TInt8
	 * int16 -> TInt16
	 * int32 -> TInt32
	 * uint8 -> TUInt8
	 * uint16 -> TUInt16
	 * uint32 -> TUInt32
	 * double -> TDouble
	 * 
	 */
	public  boolean isOfTheForm(String[] names){
		if (data.length != names.length) return false;
		for (int i=0; i<names.length; i++){
			if ((!this.names.containsKey(names[i])) ||  
					(!(this.names.get(names[i]).isAssignableFrom(data[i].getClass()))))
					return false;
		}
		return true;
	}
	
	public boolean hasId(int id){
		return this.id_int==id;
	}
	
}
