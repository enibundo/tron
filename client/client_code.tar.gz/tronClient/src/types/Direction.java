package types;

public enum Direction {
	LEFT,
	RIGHT,
	UP,
	BOTTOM
}
