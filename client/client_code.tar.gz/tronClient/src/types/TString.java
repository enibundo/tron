package types;

import tools.*;
import types.interfaces.IMyType;

public class TString extends AbstractType implements IMyType {

	private String value;
	
	public TString(String value) {
		this.value = value;
	}
	

	public TString (byte[] tab){
		this.value=new String(tab);
	}
	
	@Override
	public byte[] getBytes() {
		return value.getBytes();
	}

	@Override
	public byte[] getPBytes() {
		byte[] lenNValue = new byte[value.length() + 2];
		byte[] length = (new TUInt16(value.length())).getBytes(); 
		lenNValue = ArrayTools.concByteArrays(length, getBytes());		
		return constructArr((byte)0x20, lenNValue);
	}
	
	public String toString() {
		return "string \""+value+"\"";
	}


	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TString) {
			return this.getValue().equals(((TString) i).getValue());
		}
		return false;
	}


	public String getValue() {
		return value;
	}


	public void setValue(String value) {
		this.value = value;
	}

}
