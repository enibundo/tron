package types;

import types.interfaces.IMyType;

public class TInt8 
extends AbstractType
implements IMyType{
	private byte value;
	
	public TInt8(int value) {
		if (value < -128 
				|| value > 127) {
				throw new RuntimeException("bad value sendInt8");
		}
		this.value = (byte)value;
	}
	
	public byte[] getBytes() { 
		return new byte[]{value};
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x01, getBytes());
	}

	public String toString() {
		return "int8 "+value;
	}

	public byte getValue() {
		return value;
	}

	public void setValue(byte value) {
		this.value = value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TInt8){
			return this.getValue()==((TInt8)i).getValue();
		}
		return false;
	}
}
