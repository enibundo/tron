package types;

import types.interfaces.IMyType;


public class TUInt32 
extends AbstractType
implements IMyType{

	private long value;
	
	public TUInt32(long value){
		if (value < 0
			|| value > (long)(1L<<32 -1)){
			throw new RuntimeException("bad value TUInt32"); 
		}
		this.value=value;
	}
	
	public TUInt32(byte[] bs) {
		int first  = bs[0]<<24;
		int second = bs[1]<<16;
		int third  = bs[2]<<8;
		int fourth = bs[3];
		this.value= (first|second|third|fourth);
	}
	
	@Override
	public byte[] getBytes() {
		byte[] arr = new byte[]{
				(byte)((value >> 24) & 0xFF),
				(byte)((value >> 16) & 0xFF),
				(byte)((value >> 8) & 0xFF),
				(byte)(value & 0xFF)};
		return arr;
	}
	
	// get Prefixed Bytes
	public byte[] getPBytes() {
		return constructArr((byte)0x14, getBytes());
	}

	public String toString() {
		return "uint32 "+value;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TUInt32) {
			return this.getValue()==((TUInt32)i).getValue();
		}
		return false;
	}
	
	
}
