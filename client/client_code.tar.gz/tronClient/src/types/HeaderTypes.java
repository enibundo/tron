package types;

public enum HeaderTypes {
	
	FRAME_START ((byte) 0xFF),
	
	TYPE_INT8 ((byte) 0x01),
	TYPE_INT16 ((byte) 0x02),
	TYPE_INT32 ((byte) 0x04),
	TYPE_UINT8 ((byte) 0x11),
	TYPE_UINT16 ((byte) 0x12),
	TYPE_UINT32 ((byte) 0x14),
	TYPE_STRING ((byte) 0x20),
	TYPE_DOUBLE ((byte) 0x30)
	;
	
	private byte value; 
	HeaderTypes(byte value){
		this.value = value;
	}
	
	public boolean equals(byte i){
		return value==i;
	}
	
}
