package types;

import types.interfaces.IMyType;


public class TInt16 
extends AbstractType 
implements IMyType
{
	
	private int value;
	

	public TInt16(int value){
		if (value < -32768 
			|| value > 32767) {
			throw new RuntimeException("bad value TInt16");
		}
		this.value=value;
	}
	
	@Override
	public byte[] getBytes() {
		byte[] arr = new byte[]{
				(byte)((value >> 8) & 0xFF),
				(byte)(value & 0xFF)
				};
		return arr;
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x02, getBytes());
	}
	
	public String toString() {
		return "int16 "+value;
	}

	
	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TInt16){
			return this.getValue()==((TInt16)i).getValue();
		}
		return false;
	}
	
	
}
