package types;

import types.interfaces.IMyType;


public class TInt32 
extends AbstractType
implements IMyType{
	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}

	private long value;
	
	public TInt32(long value){
		if (value < -2147483648
				|| value > 2147483647){
			throw new RuntimeException("bad value TInt32");
		}
		this.value = value;
	}
	
	public TInt32(byte[] values){
		value = (long)( values[0] << 24 |
						values[1] << 16 |
						values[2] << 8 |
						values[3]);
	}
	
	
	@Override
	public byte[] getBytes() {
		byte[] arr = new byte[]{
				(byte)((value >> 24) & 0xFF),
				(byte)((value >> 16) & 0xFF),
				(byte)((value >> 8) & 0xFF),
				(byte)(value & 0xFF)};
		return arr;
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x04, getBytes());
	}
	
	public String toString() {
		return "int32 "+value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TInt32) {
			return this.getValue()==((TInt32)i).getValue();
		}
		return false;
	}

}
