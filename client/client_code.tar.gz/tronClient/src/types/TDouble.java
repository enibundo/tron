package types;

import java.nio.ByteBuffer;
import types.interfaces.IMyType;

public class TDouble 
extends AbstractType 
implements IMyType{

	public double getValue() {
		return value;
	}


	public void setValue(double value) {
		this.value = value;
	}


	private double value;
	
	public TDouble(double val){
	   if (val < Double.MIN_VALUE || val > Double.MAX_VALUE){
		   throw new RuntimeException("Bad value TDouble");
	   }
	   this.value=val;
	}
	
	
	@Override
	public byte[] getBytes() {
		return toByteArray(this.value);
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x30, getBytes());
	}

	public static byte[] toByteArray(double value) {    
		byte[] bytes = new byte[8]; 
		ByteBuffer.wrap(bytes).putDouble(value);     
		return bytes; 
	}
	
	public static double toDouble(byte[] bytes) {    
		return ByteBuffer.wrap(bytes).getDouble(); 
	}


	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TDouble){
			return this.getValue()==((TDouble)i).getValue();
		}
		return false;
	} 

	
	
	
}