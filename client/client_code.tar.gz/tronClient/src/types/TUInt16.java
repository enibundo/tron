package types;

import types.interfaces.IMyType;


public class TUInt16 
extends AbstractType
implements IMyType{
	private int value;
	
	public TUInt16(int value){
		if (value<0 || value>(1<<16 -1)){
			throw new RuntimeException("bad value TUInt16");
		}
		this.value = value;
	}
	
	public TUInt16(byte[] bs) {
		int val1 = (bs[0]<<8)&0xFFFF;
		int val2 = (bs[1])&0xFF;
		this.value=(int)(val1 | val2);
	}
	
	@Override
	public byte[] getBytes() {
		byte[] arr = new byte[]{
				(byte)((value >> 8) & 0xFF),
				(byte)(value & 0xFF)
				};
		return arr;
	}

	@Override
	public byte[] getPBytes() {
		return constructArr((byte)0x12, getBytes());
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String toString() {
		return "uint16 "+value;
	}

	@Override
	public boolean equals(IMyType i) {
		if (i instanceof TUInt16) {
			return this.getValue()==((TUInt16)i).getValue();
		}
		return false;
	}
	
}
