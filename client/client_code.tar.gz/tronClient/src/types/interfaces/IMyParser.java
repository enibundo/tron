package types.interfaces;

import java.io.IOException;

import types.*;

public interface IMyParser {
	
	public TFrame parseFrame() throws IOException;
	public TInt8 parseInt8() throws IOException;
	public TInt16 parseInt16() throws IOException;
	public TInt32 parseInt32() throws IOException;
	public TUInt8 parseUInt8() throws IOException;
	public TUInt16 parseUInt16() throws IOException;
	public TUInt32 parseUInt32() throws IOException;
	public TString parseString() throws IOException;
	public TDouble parseDouble() throws IOException;
	

}
