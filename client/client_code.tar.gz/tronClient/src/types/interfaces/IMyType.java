package types.interfaces;
import types.HeaderTypes;
public interface IMyType {
	final HeaderTypes hType=null;
	public byte[] getBytes();
	// prefixed bytes
	public byte[] getPBytes();
	public boolean equals(IMyType i);
}
