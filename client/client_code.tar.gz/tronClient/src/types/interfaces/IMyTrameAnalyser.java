package types.interfaces;

import types.*;

public interface IMyTrameAnalyser {
	public boolean equal(TFrame f1, TFrame f2);
	public int getLen(TFrame f1);
	public int getId(TFrame f1);
}
