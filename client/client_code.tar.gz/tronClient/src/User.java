import java.awt.Color;


public class User {

	private int id;
	
	private int red;
	private int green;
	private int blue;
	
	private String nickname;

	private int oldPosx;
	private int oldPosy;
	
	private int posx;
	private int posy;
	
	private int direction;
	private int speed;
	
	
	
	public User(int id, int red, int green, int blue, String nickname, int posx, int posy, int direction, int speed) { 
		this.id = id;
		this.blue = blue;
		this.red = red;
		this.green = green;
		this.nickname = nickname;
		this.posx = posx;
		this.posy = posy;
		
		this.oldPosx=posx;
		this.oldPosy=posy;
		
		this.direction = direction;
		this.speed = speed;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRed() {
		return red;
	}

	public void setRed(int red) {
		this.red = red;
	}

	public int getGreen() {
		return green;
	}

	public void setGreen(int green) {
		this.green = green;
	}

	public int getBlue() {
		return blue;
	}

	public void setBlue(int blue) {
		this.blue = blue;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getPosx() {
		return posx;
	}

	public void setPosx(int posx) {
		this.setOldPosx(this.posx);
		this.posx = posx;
	}

	public int getPosy() {
		return posy;
	}

	public void setPosy(int posy) {
		this.setOldPosy(this.posy);
		this.posy = posy;
	}

	public int getDirection() {
		return direction;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public String toString(){ 
		return "<"+nickname+"> : [(r:"+red+", g:"+green+", b:"+blue+"), (x:"+posx+", y:"+posy+"), (d:"+direction+", s:"+speed+")]";
	}

	public Color getColor() { 
		return new Color(red, green, blue);
	}

	public int getOldPosx() {
		return oldPosx;
	}

	public void setOldPosx(int oldPosx) {
		this.oldPosx = oldPosx;
	}

	public int getOldPosy() {
		return oldPosy;
	}

	public void setOldPosy(int oldPosy) {
		this.oldPosy = oldPosy;
	}
}
