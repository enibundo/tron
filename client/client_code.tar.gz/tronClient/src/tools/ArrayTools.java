package tools;

public class ArrayTools {

	public static byte[] concByteArrays(byte[] arr1, byte[] arr2){
		byte[] res = new byte[arr1.length+arr2.length];
		System.arraycopy(arr1, 0, res, 0, arr1.length);
		System.arraycopy(arr2, 0, res, arr1.length, arr2.length);
		return res;
	}
	
	public static boolean equal(byte[] f1, byte[] f2){
		// if same object
		if (f1.equals(f2)) return true;
		
		// if different lengths
		if (f1.length != f2.length) return false;
		
		// parce que f1.equals(f2) allait renvoier tojours faux :) 
		for (int i=0; i<f1.length; i++) {
			if (f1[i] != f2[i]) return false;
		}
		return true;
	}
}
