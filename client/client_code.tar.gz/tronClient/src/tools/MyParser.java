package tools;

import java.io.DataInputStream;
import java.io.IOException;

import types.*;
import types.interfaces.IMyParser;
import types.interfaces.IMyType;

public class MyParser 
implements IMyParser {

	private DataInputStream is;
	
	public MyParser(DataInputStream is){
		this.is = is;
	}
	
	public TFrame parseFrame() throws IOException {
		byte start = is.readByte();
		int id = is.readByte();
		byte n = is.readByte();
		
		if (! HeaderTypes.FRAME_START.equals(start)) {
			throw new RuntimeException("bad starting header of frame (parseFrame)");
		}
		
		IMyType[] data = new IMyType[n];
		
		for (int i=0; i<n; i++)
			data[i] = this.parseData();
		
		return new TFrame(id, data);
	}
	
	public IMyType parseData() throws IOException {
		byte type = is.readByte();
		
		if (HeaderTypes.TYPE_INT8.equals(type)) {
            return (IMyType) parseInt8();
		}
		
		if (HeaderTypes.TYPE_INT16.equals(type)) {
			return (IMyType) parseInt16();
		}
		
		if (HeaderTypes.TYPE_INT32.equals(type)) {
			return (IMyType) parseInt32();
		}
		
		if (HeaderTypes.TYPE_UINT8.equals(type)) {
			return (IMyType) parseUInt8();
		}
		
		if (HeaderTypes.TYPE_UINT16.equals(type)) {
			return (IMyType) parseUInt16();
		}
		
		if (HeaderTypes.TYPE_UINT32.equals(type)) {
			return (IMyType) parseInt32();
		}
		
		if (HeaderTypes.TYPE_STRING.equals(type)) {
			return (IMyType) parseString();
		}
		
		if (HeaderTypes.TYPE_DOUBLE.equals(type)) {
			return parseDouble();
		}
	
		throw new RuntimeException("bad header value for data (parseData)");
	}

	@Override
	public TDouble parseDouble() throws IOException {
        double value=is.readDouble();
		return new TDouble(value);
	}

	@Override
	public TInt16 parseInt16() throws IOException {
	    short value=is.readShort();
		return new TInt16(value);
	}

	@Override
	public TInt32 parseInt32() throws IOException {
		int value=is.readInt();
		return new TInt32(value);
	}

	@Override
	public TInt8 parseInt8() throws IOException {
		byte value = is.readByte();
		return new TInt8(value);
	}

	@Override
	public TString parseString() throws IOException {
		short len= is.readShort();
		byte[] tab= new byte[len];
		for (int i=0;i<len;i++){
			tab[i]=is.readByte();
		}
		return new TString(tab);
	}

	@Override
	public TUInt16 parseUInt16() throws IOException {
		byte haut=is.readByte();
		byte bas=is.readByte();
		return new TUInt16(new byte[]{haut, bas});
	}

	@Override
	public TUInt32 parseUInt32() throws IOException {
		byte first=is.readByte();
		byte second=is.readByte();
		byte third=is.readByte();
		byte fourth=is.readByte();
		return new TUInt32(new byte[]{first, second, third, fourth});
	}

	@Override
	public TUInt8 parseUInt8() throws IOException {
		byte value = is.readByte();
		return new TUInt8 ((short)((int)value&0xFF));
	}
	
}