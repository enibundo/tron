package tools;

import types.TFrame;
import types.TString;
import types.TUInt8;
import types.interfaces.IMyType;

public class FrameAnalyser {

	public static TFrame constructCFrame(int r, int g, int b, String name) {
		IMyType[] k = new IMyType[4];
		k[0] = new TUInt8(r);
		k[1] = new TUInt8(g);
		k[2] = new TUInt8(b);
		k[3] = new TString(name);
		return new TFrame(0x43, k);
	}
	
	public static TFrame iFrame() { 
		IMyType[] k = new IMyType[2];
		k[0]=new TString("PC2RON?");
		k[1]=new TString("PC2RON2011");
		return (new TFrame(0x49, k));
	}
	
	public static TFrame aFrame() { 
		IMyType[] k = new IMyType[2];
		k[0]=new TString("OK");
		k[1]=new TString("PC2RON2011");
		return (new TFrame(0x41, k));
	}
	
	public static TFrame endUsersFrame() {
		return new TFrame(0x45);
	}
	
	public static TFrame turnLeftFrame() {
		IMyType[] k = new IMyType[1];
		k[0] = new TString("left");
		return new TFrame(0x4F, k);
	}
	
	public static TFrame turnRightFrame() {
		IMyType[] k = new IMyType[1];
		k[0] = new TString("right");
		return new TFrame(0x4F, k);
	}
	
	public static TFrame idleFrame() {
		IMyType[] k = new IMyType[1];
		k[0] = new TString("idle");
		return new TFrame(0x4F, k);
	}
}
