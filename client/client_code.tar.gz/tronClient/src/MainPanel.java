import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;


public class MainPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<User> others;
	
	private String message;
	
	public MainPanel(){ 
		super();
		setPreferredSize(new Dimension(1000, 1000));
		setVisible(true);
		setFocusable(true);
		others = null;
		message=null;
	}
	
	@Override
	public void paint(final Graphics g){

		Graphics2D g2d = (Graphics2D)g;
		g2d.setBackground(Color.black);
		if (message!=null ) {
			g2d.setColor(Color.red);
			g2d.setFont(new Font("Verdana", Font.BOLD, 145));
			g2d.drawString(message, 500, 500);
		} else {
			if (others != null) {
				g2d.setStroke(new BasicStroke(1));
			
				for (User u:others){
					//System.out.println("drawing "+u.getPosx()+", "+u.getPosy());
					g2d.setColor(u.getColor());
					g2d.drawLine(u.getPosy(), u.getPosx(), u.getOldPosy(), u.getOldPosx());
					//g2d.setColor(Color.gray);
					g2d.setColor(g2d.getColor().darker().darker());
					
					if (u.getDirection()==1 || 
						u.getDirection() == 2) {
						g2d.drawLine(u.getPosy()+1, u.getPosx(), u.getOldPosy()+1, u.getOldPosx());
						g2d.drawLine(u.getPosy()-1, u.getPosx(), u.getOldPosy()-1, u.getOldPosx());
					} else {
						g2d.drawLine(u.getPosy(), u.getPosx()+1, u.getOldPosy(), u.getOldPosx()+1);
						g2d.drawLine(u.getPosy(), u.getPosx()-1, u.getOldPosy(), u.getOldPosx()-1);
					}
				}
			}
		}
	}
	
	public void setMessage(String a) { 
		this.message = a;
	}
	
	public void setOthers(ArrayList<User> others){
		this.others = others;
	}

	
	
}
