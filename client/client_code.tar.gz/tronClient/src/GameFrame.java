

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import javax.swing.WindowConstants;

public class GameFrame extends javax.swing.JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MainFrame main;
	private MainPanel mp;
	
	public GameFrame(MainFrame main) {
		super();
		
		this.main = main;
		
		setEnabled(true);
		setVisible(true);
		setFocusable(true);
		setBackground(Color.black);
		
		main.setVisible(false);
		main.setFocusable(false);
		
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			mp = new MainPanel();
			
			mp.setPreferredSize(new Dimension(1000,1000));
			this.addKeyListener(new KeyListener(){
				@Override
				public void keyPressed(KeyEvent arg0) {
					System.err.println(" ***KEY PRESSED ***");
					try { 
						switch (arg0.getKeyCode()) {
					case KeyEvent.VK_LEFT:
						main.getClient().leftPressed();
						break;
					case KeyEvent.VK_RIGHT:
						main.getClient().rightPressed();
						break;
					case KeyEvent.VK_UP:
						main.getClient().upPressed();
						break;
					case KeyEvent.VK_DOWN:
						main.getClient().downPressed();
						break;
					}
				}catch (IOException io){
						
				}
			}
				
				@Override
				public void keyReleased(KeyEvent arg0) {
					System.err.println(" ***KEY PRESSED ***");
				}

				@Override
				public void keyTyped(KeyEvent arg0) {
					System.err.println(" ***KEY PRESSED ***");
				}});
			this.add(mp);

			pack();
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	public MainPanel getPanel(){
		return mp;
	}

}
