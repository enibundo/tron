import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import tools.*;
import types.TFrame;
import types.TString;
import types.TUInt16;
import types.TUInt8;
import types.interfaces.IMyType;

public class Client {
	private static DataOutputStream os;
	private MyParser parser;
	
	private String nickname;
	private int[] colors;
	
	private static ArrayList<User> others;
	
	private static User myUser;
	private static int myId;
	
	private GameFrame g;
	
	public Client(DataInputStream is, DataOutputStream os, String nickname, int[] colors, GameFrame g){
		this.nickname=nickname;
		this.colors=colors;
		Client.os = os;
		
		parser = new MyParser(is);
		
		others = new ArrayList<User>();
		this.g=g;
	}
	
	public void run(){ 
		(new Thread(){
			public void run(){	TFrame response = null;
			try {
				// send I-Frame
				Client.send(FrameAnalyser.iFrame());

				response = parser.parseFrame();

				// if answer is an a-Frame
				if (response.equals(FrameAnalyser.aFrame())) {
					Client.send(FrameAnalyser.constructCFrame(colors[0], colors[1], colors[2], nickname));
					response = parser.parseFrame();
					if (response.isOfTheForm(new String[]{"string", "uint16"})){
						if (response.hasData(0, new TString("OK"))) {
							myId = ((TUInt16)response.getData(1)).getValue();
							while (!response.equals(FrameAnalyser.endUsersFrame())) {
								response = parser.parseFrame();
								if (!(response.isEmpty()))  {
									Client.addUser(response);
								}
							}

							response = parser.parseFrame();
							
								
							while (response.hasId(0x50)) {
								g.getPanel().repaint();
								System.out.println("--->"+((TString)response.getData(0)).getValue());
								response = parser.parseFrame();
							}
							
							g.getPanel().setMessage(null);
							
							if (response.hasId(0x53)){
								g.getPanel().setOthers(others);
								response = parser.parseFrame();
								g.getPanel().repaint();
								while (!response.hasId(0x57)) {
									
									if (response.hasId(0x44)) {
										if (((TUInt16)response.getData(0)).getValue() == myId){
											g.getPanel().setMessage("DEAD");
											System.out.println("IM DEAD");
											break;
											
										}
									}
									
									System.out.println(response);
									response = parser.parseFrame();
									updateOthers(response);
									g.getPanel().setOthers(others);
									g.getPanel().repaint();
								}
								g.getPanel().repaint();
							}
						}
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
			}}).start();
		
	}
	
	private User getUserWithId(int i){
		for (User u:others){
			if (u.getId()==i)
				return u;
		}
		return null;
	}
	
	private void updateOthers(TFrame r) {
		IMyType data[] = r.getData();
		int dataLength = data.length;
		int users = (dataLength -1)/4;
		
		for (int i = 0; i<users; i++) {
			int id = ((TUInt16)r.getData(4*i+1)).getValue();
			int x = ((TUInt16)r.getData(4*i+2)).getValue();
			int y = ((TUInt16)r.getData(4*i+3)).getValue();
			int d = ((TUInt16)r.getData(4*i+4)).getValue();
			
			User toUpdate = getUserWithId(id);
			toUpdate.setPosx(x);
			toUpdate.setPosy(y);
			toUpdate.setDirection(d);
		}
	}
	
	public static void addUser(TFrame response) {
		int id = ((TUInt16)response.getData(0)).getValue();
		String nickname = ((TString)response.getData(1)).getValue();
		
		int red = ((TUInt8)response.getData(2)).getValue();
		int green = ((TUInt8)response.getData(3)).getValue();
		int blue = ((TUInt8)response.getData(4)).getValue();
		
		int positionx = ((TUInt16)response.getData(5)).getValue();
		int positiony = ((TUInt16)response.getData(6)).getValue();
		
		int direction = ((TUInt8)response.getData(7)).getValue();
		int speed = ((TUInt8)response.getData(8)).getValue();
		User tmp = new User(id, red, green, blue, nickname, positionx, positiony, direction, speed);
		if (id == myId)
			myUser = tmp;
		others.add(tmp);
	}

	public static void send(TFrame f) throws IOException{
		System.out.println("writing! "+f.toString());
		os.write(f.getPBytes());
	}
	
	public void rightPressed() throws IOException{
		int oldDirection = myUser.getDirection();
		switch(oldDirection){
		case 1:
			Client.send(FrameAnalyser.turnRightFrame());
			myUser.setDirection(4);
			break;
		case 2:
			Client.send(FrameAnalyser.turnLeftFrame());
			myUser.setDirection(4);
			break;
		case 3:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 4:
			Client.send(FrameAnalyser.idleFrame());
			break;
		}	
	}
	
	public void leftPressed() throws IOException{
		int oldDirection = myUser.getDirection();
		switch(oldDirection){
		case 1:
			Client.send(FrameAnalyser.turnLeftFrame());
			myUser.setDirection(3);
			break;
		case 2:
			Client.send(FrameAnalyser.turnRightFrame());
			myUser.setDirection(3);
			break;
		case 3:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 4:
			Client.send(FrameAnalyser.idleFrame());
			break;
		}	
	}
	
	public void upPressed() throws IOException{
		int oldDirection = myUser.getDirection();

		switch(oldDirection){
		case 1:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 2:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 3:
			Client.send(FrameAnalyser.turnRightFrame());
			myUser.setDirection(1);
			break;
		case 4:
			Client.send(FrameAnalyser.turnLeftFrame());
			myUser.setDirection(1);
			break;
		}
	}
		
	public void downPressed() throws IOException{
		int oldDirection = myUser.getDirection();
		switch(oldDirection){
		case 1:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 2:
			Client.send(FrameAnalyser.idleFrame());
			break;
		case 3:
			Client.send(FrameAnalyser.turnLeftFrame());
			myUser.setDirection(2);
			break;
		case 4:
			Client.send(FrameAnalyser.turnRightFrame());
			myUser.setDirection(2);
			break;
		}
	}	
}
